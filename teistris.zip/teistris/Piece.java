package teistris;

public abstract class Piece {
    protected Game game;
    protected Square[] squares;

    public Piece(Game game) {
        this.game = game;
        squares = new Square[4];
    }

    public Square[] getSquares() {
        return squares;
    }

    public boolean moveRight() {
        // Check if movement is possible
        for (Square square : squares) {
            if (!game.isValidPosition(square.getX() + Game.SQUARE_SIDE, square.getY())) {
                return false;
            }
        }
        
        // Move all squares
        for (Square square : squares) {
            square.setX(square.getX() + Game.SQUARE_SIDE);
        }
        return true;
    }

    public boolean moveLeft() {
        for (Square square : squares) {
            if (!game.isValidPosition(square.getX() - Game.SQUARE_SIDE, square.getY())) {
                return false;
            }
        }
        
        for (Square square : squares) {
            square.setX(square.getX() - Game.SQUARE_SIDE);
        }
        return true;
    }

    public boolean moveDown() {
        for (Square square : squares) {
            if (!game.isValidPosition(square.getX(), square.getY() + Game.SQUARE_SIDE)) {
                return false;
            }
        }
        
        for (Square square : squares) {
            square.setY(square.getY() + Game.SQUARE_SIDE);
        }
        return true;
    }

    public abstract boolean rotate();
}