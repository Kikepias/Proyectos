package teistris;

import java.awt.Color;

public class SquarePiece extends Piece {
    public SquarePiece(Game game) {
        super(game);
        squares[0] = new Square(Game.MAX_X / 2 - Game.SQUARE_SIDE, 0, Color.YELLOW, game);
        squares[1] = new Square(Game.MAX_X / 2, 0, Color.YELLOW, game);
        squares[2] = new Square(Game.MAX_X / 2 - Game.SQUARE_SIDE, Game.SQUARE_SIDE, Color.YELLOW, game);
        squares[3] = new Square(Game.MAX_X / 2, Game.SQUARE_SIDE, Color.YELLOW, game);
    }

    @Override
    public boolean rotate() {
        // Square piece doesn't need rotation
        return true;
    }
}