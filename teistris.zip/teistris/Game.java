package teistris;

import java.util.HashMap;
import java.util.Map;

/**
 * Clase que implementa o comportamento do xogo do Tetris
 * @author Profe de Programación
 */
public class Game {

    /**
     * Constante que define o tamaño en pixels do lado dun cadrado
     */
    public final static int SQUARE_SIDE = 20;
    /**
     * Constante que define o valor máximo da coordenada x no panel de cadrados
     */
    public final static int MAX_X = 160;
    
    /**
     * Constante que define o valor máximo da coordenada y no panel de cadrados
     */
    public final static int MAX_Y = 200;

    /**
     * Referenza á peza actual do xogo, que é a única que se pode mover
     */
    private Piece currentPiece;

    /**
     * Referenza á ventá principal do xogo
     */
    private MainWindow mainWindow;

    /**
     * Flag que indica se o xogo está en pausa ou non
     */
    private boolean paused = false;

    /**
     * Número de liñas feitas no xogo
     */
    private int numberOfLines = 0;

    private Map<String, Square> groundSquares;

    public Game(MainWindow mainWindow) {
        this.mainWindow = mainWindow;
        this.groundSquares = new HashMap<>();
        this.createNewPiece();
    }

    public MainWindow getMainWindow() {
        return mainWindow;
    }

    public void setMainWindow(MainWindow mainWindow) {
        this.mainWindow = mainWindow;
    }

    public boolean isPaused() {
        return paused;
    }

    public void setPaused(boolean paused) {
        this.paused = paused;
    }

    public int getNumberOfLines() {
        return numberOfLines;
    }

    public void setNumberOfLines(int numberOfLines) {
        this.numberOfLines = numberOfLines;
    }

    public boolean isValidPosition(int x, int y) {
        if ((x == MAX_X) || (x < 0) || (y == MAX_Y) || (y < 0)) {
            return false;
        }
        String coordinates = x + "," + y;
        return !groundSquares.containsKey(coordinates);
    }

    private void addPieceToGround() {
        for (Square square : currentPiece.getSquares()) {
            groundSquares.put(square.getCoordinates(), square);
        }
        this.deleteCompletedLines();
    }

    private void deleteCompletedLines() {
        for (int y = 0; y < MAX_Y; y += SQUARE_SIDE) {
            int squaresInLine = 0;
            for (int x = 0; x < MAX_X; x += SQUARE_SIDE) {
                if (groundSquares.containsKey(x + "," + y)) {
                    squaresInLine++;
                }
            }
            if (squaresInLine == MAX_X / SQUARE_SIDE) {
                deleteLine(y);
                numberOfLines++;
                mainWindow.showNumberOfLines(numberOfLines);
            }
        }
    }

    private void deleteLine(int y) {
        // Delete squares in the line
        for (int x = 0; x < MAX_X; x += SQUARE_SIDE) {
            String coordinates = x + "," + y;
            Square square = groundSquares.remove(coordinates);
            if (square != null) {
                mainWindow.deleteSquare(square.getLblSquare());
            }
        }

        // Move squares above down
        Map<String, Square> newGroundSquares = new HashMap<>();
        for (Map.Entry<String, Square> entry : groundSquares.entrySet()) {
            Square square = entry.getValue();
            if (square.getY() < y) {
                square.setY(square.getY() + SQUARE_SIDE);
                newGroundSquares.put(square.getCoordinates(), square);
            } else {
                newGroundSquares.put(entry.getKey(), square);
            }
        }
        groundSquares = newGroundSquares;
    }

    private boolean hitPieceTheGround() {
        for (Square square : currentPiece.getSquares()) {
            String coordinates = square.getCoordinates();
            if (groundSquares.containsKey(coordinates)) {
                return true;
            }
        }
        return false;
    }

    private void createNewPiece() {
        int pieceType = new java.util.Random().nextInt(2); // For 2 piece types
        switch(pieceType) {
            case 0:
                currentPiece = new SquarePiece(this);
                break;
            case 1:
                currentPiece = new LPiece(this);
                break;
        }
    }
}