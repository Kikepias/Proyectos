package teistris;

import java.awt.Color;

public class LPiece extends Piece {
    private int rotation = 0;

    public LPiece(Game game) {
        super(game);
        squares[0] = new Square(Game.MAX_X / 2 - Game.SQUARE_SIDE, 0, Color.GREEN, game);
        squares[1] = new Square(Game.MAX_X / 2 - Game.SQUARE_SIDE, Game.SQUARE_SIDE, Color.GREEN, game);
        squares[2] = new Square(Game.MAX_X / 2 - Game.SQUARE_SIDE, Game.SQUARE_SIDE * 2, Color.GREEN, game);
        squares[3] = new Square(Game.MAX_X / 2, Game.SQUARE_SIDE * 2, Color.GREEN, game);
    }

    @Override
    public boolean rotate() {
        int[][] rotations = new int[4][2];
        rotation = (rotation + 1) % 4;
        
        switch(rotation) {
            case 0: // Initial position
                rotations[0] = new int[]{-1, 0};
                rotations[1] = new int[]{-1, 1};
                rotations[2] = new int[]{-1, 2};
                rotations[3] = new int[]{0, 2};
                break;
            case 1: // 90 degrees
                rotations[0] = new int[]{0, 1};
                rotations[1] = new int[]{1, 1};
                rotations[2] = new int[]{2, 1};
                rotations[3] = new int[]{2, 0};
                break;
            case 2: // 180 degrees
                rotations[0] = new int[]{1, 2};
                rotations[1] = new int[]{1, 1};
                rotations[2] = new int[]{1, 0};
                rotations[3] = new int[]{2, 0};
                break;
            case 3: // 270 degrees
                rotations[0] = new int[]{2, 1};
                rotations[1] = new int[]{1, 1};
                rotations[2] = new int[]{0, 1};
                rotations[3] = new int[]{0, 2};
                break;
        }

        // Check if rotation is possible
        int baseX = squares[1].getX();
        int baseY = squares[1].getY();
        
        for (int i = 0; i < 4; i++) {
            int newX = baseX + rotations[i][0] * Game.SQUARE_SIDE;
            int newY = baseY + rotations[i][1] * Game.SQUARE_SIDE;
            if (!game.isValidPosition(newX, newY)) {
                rotation = (rotation + 3) % 4; // Revert rotation
                return false;
            }
        }

        // Apply rotation
        for (int i = 0; i < 4; i++) {
            squares[i].setX(baseX + rotations[i][0] * Game.SQUARE_SIDE);
            squares[i].setY(baseY + rotations[i][1] * Game.SQUARE_SIDE);
        }
        
        return true;
    }
}