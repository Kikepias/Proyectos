package teistris;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainWindow extends JFrame {
    private JPanel gamePanel;
    private JLabel lblLines;
    private Game game;

    public MainWindow() {
        setTitle("Tetris");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        // Create game panel
        gamePanel = new JPanel();
        gamePanel.setLayout(null);
        gamePanel.setPreferredSize(new Dimension(Game.MAX_X + 100, Game.MAX_Y));
        gamePanel.setBackground(Color.WHITE);

        // Create score panel
        JPanel scorePanel = new JPanel();
        scorePanel.setBounds(Game.MAX_X + 10, 10, 80, 50);
        scorePanel.setBorder(BorderFactory.createTitledBorder("Lines"));
        lblLines = new JLabel("0");
        scorePanel.add(lblLines);
        gamePanel.add(scorePanel);

        add(gamePanel);
        pack();
        setLocationRelativeTo(null);

        // Create game instance
        game = new Game(this);

        // Add key listener for controls
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (!game.isPaused()) {
                    switch (e.getKeyCode()) {
                        case KeyEvent.VK_LEFT:
                            game.getCurrentPiece().moveLeft();
                            break;
                        case KeyEvent.VK_RIGHT:
                            game.getCurrentPiece().moveRight();
                            break;
                        case KeyEvent.VK_DOWN:
                            game.getCurrentPiece().moveDown();
                            break;
                        case KeyEvent.VK_UP:
                            game.getCurrentPiece().rotate();
                            break;
                        case KeyEvent.VK_P:
                            game.setPaused(true);
                            break;
                    }
                } else if (e.getKeyCode() == KeyEvent.VK_P) {
                    game.setPaused(false);
                }
            }
        });
    }

    public void drawSquare(JLabel square) {
        gamePanel.add(square);
        gamePanel.repaint();
    }

    public void deleteSquare(JLabel square) {
        gamePanel.remove(square);
        gamePanel.repaint();
    }

    public void showNumberOfLines(int lines) {
        lblLines.setText(String.valueOf(lines));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainWindow window = new MainWindow();
            window.setVisible(true);
        });
    }
}