package tacebook;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

/**
 * Panel for displaying and managing friends in the Tacebook application
 */
public class FriendsPanel extends JPanel {
    private Tacebook app;
    private JList<User> friendsList;
    private DefaultListModel<User> friendsModel;
    private JButton addFriendButton;
    private JButton removeFriendButton;
    private JTextField searchField;
    private JButton searchButton;
    
    public FriendsPanel(Tacebook app) {
        this.app = app;
        setLayout(new BorderLayout());
        
        // Create title panel
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(new Color(59, 89, 152)); // Facebook blue
        JLabel titleLabel = new JLabel("Friends");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel, BorderLayout.CENTER);
        
        // Create navigation panel
        JPanel navPanel = new JPanel();
        navPanel.setBackground(new Color(59, 89, 152));
        JButton homeButton = new JButton("Home");
        JButton profileButton = new JButton("Profile");
        JButton logoutButton = new JButton("Logout");
        
        homeButton.addActionListener(e -> app.showNewsFeedPanel());
        profileButton.addActionListener(e -> app.showProfilePanel());
        logoutButton.addActionListener(e -> app.logout());
        
        navPanel.add(homeButton);
        navPanel.add(profileButton);
        navPanel.add(logoutButton);
        titlePanel.add(navPanel, BorderLayout.SOUTH);
        
        // Create friends list panel
        JPanel friendsPanel = new JPanel(new BorderLayout());
        friendsPanel.setBorder(BorderFactory.createTitledBorder("My Friends"));
        
        friendsModel = new DefaultListModel<>();
        friendsList = new JList<>(friendsModel);
        friendsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(friendsList);
        scrollPane.setPreferredSize(new Dimension(400, 200));
        
        // Create buttons panel
        JPanel buttonsPanel = new JPanel();
        addFriendButton = new JButton("Add Friend");
        removeFriendButton = new JButton("Remove Friend");
        
        addFriendButton.addActionListener(e -> addFriend());
        removeFriendButton.addActionListener(e -> removeFriend());
        
        buttonsPanel.add(addFriendButton);
        buttonsPanel.add(removeFriendButton);
        
        friendsPanel.add(scrollPane, BorderLayout.CENTER);
        friendsPanel.add(buttonsPanel, BorderLayout.SOUTH);
        
        // Create search panel
        JPanel searchPanel = new JPanel(new BorderLayout());
        searchPanel.setBorder(BorderFactory.createTitledBorder("Find Friends"));
        
        searchField = new JTextField();
        searchButton = new JButton("Search");
        
        searchButton.addActionListener(e -> searchUsers());
        
        searchPanel.add(searchField, BorderLayout.CENTER);
        searchPanel.add(searchButton, BorderLayout.EAST);
        
        // Add components to main panel
        add(titlePanel, BorderLayout.NORTH);
        add(friendsPanel, BorderLayout.CENTER);
        add(searchPanel, BorderLayout.SOUTH);
    }
    
    public void updateFriendsList() {
        friendsModel.clear();
        User currentUser = app.getCurrentUser();
        
        if (currentUser != null) {
            for (User friend : currentUser.getFriends()) {
                friendsModel.addElement(friend);
            }
        }
    }
    
    private void addFriend() {
        String username = JOptionPane.showInputDialog(this, "Enter username to add as friend:");
        if (username != null && !username.trim().isEmpty()) {
            User currentUser = app.getCurrentUser();
            User friend = app.getUserDatabase().getUser(username);
            
            if (friend == null) {
                JOptionPane.showMessageDialog(this, "User not found", 
                                           "Error", JOptionPane.ERROR_MESSAGE);
            } else if (friend == currentUser) {
                JOptionPane.showMessageDialog(this, "You cannot add yourself as a friend", 
                                           "Error", JOptionPane.ERROR_MESSAGE);
            } else if (currentUser.getFriends().contains(friend)) {
                JOptionPane.showMessageDialog(this, "User is already your friend", 
                                           "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                currentUser.addFriend(friend);
                friend.addFriend(currentUser); // Reciprocal friendship
                updateFriendsList();
                JOptionPane.showMessageDialog(this, "Friend added successfully");
            }
        }
    }
    
    private void removeFriend() {
        User selectedFriend = friendsList.getSelectedValue();
        if (selectedFriend != null) {
            User currentUser = app.getCurrentUser();
            currentUser.removeFriend(selectedFriend);
            selectedFriend.removeFriend(currentUser); // Reciprocal removal
            updateFriendsList();
            JOptionPane.showMessageDialog(this, "Friend removed successfully");
        } else {
            JOptionPane.showMessageDialog(this, "Please select a friend to remove", 
                                         "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void searchUsers() {
        String query = searchField.getText().trim();
        if (!query.isEmpty()) {
            List<User> results = app.getUserDatabase().searchUsers(query);
            
            if (results.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No users found");
            } else {
                User[] usersArray = results.toArray(new User[0]);
                User selectedUser = (User) JOptionPane.showInputDialog(
                    this,
                    "Select a user to add as friend:",
                    "Search Results",
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    usersArray,
                    usersArray[0]);
                
                if (selectedUser != null) {
                    User currentUser = app.getCurrentUser();
                    
                    if (selectedUser == currentUser) {
                        JOptionPane.showMessageDialog(this, "You cannot add yourself as a friend", 
                                                   "Error", JOptionPane.ERROR_MESSAGE);
                    } else if (currentUser.getFriends().contains(selectedUser)) {
                        JOptionPane.showMessageDialog(this, "User is already your friend", 
                                                   "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        currentUser.addFriend(selectedUser);
                        selectedUser.addFriend(currentUser); // Reciprocal friendship
                        updateFriendsList();
                        JOptionPane.showMessageDialog(this, "Friend added successfully");
                    }
                }
            }
        }
    }
}