package tacebook;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Represents a post in the Tacebook social media application
 */
public class Post {
    private String content;
    private LocalDateTime timestamp;
    private User author;
    
    public Post(String content) {
        this.content = content;
        this.timestamp = LocalDateTime.now();
    }
    
    public Post(String content, User author) {
        this.content = content;
        this.timestamp = LocalDateTime.now();
        this.author = author;
    }
    
    public String getContent() {
        return content;
    }
    
    public LocalDateTime getTimestamp() {
        return timestamp;
    }
    
    public User getAuthor() {
        return author;
    }
    
    public void setAuthor(User author) {
        this.author = author;
    }
    
    public String getFormattedTimestamp() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM d, yyyy h:mm a");
        return timestamp.format(formatter);
    }
    
    @Override
    public String toString() {
        String authorText = (author != null) ? author.getFullName() : "Unknown";
        return authorText + " - " + getFormattedTimestamp() + "\n" + content;
    }
}