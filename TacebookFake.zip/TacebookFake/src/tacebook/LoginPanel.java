package tacebook;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Panel for user login in the Tacebook application
 */
public class LoginPanel extends JPanel {
    private Tacebook app;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton registerButton;
    
    public LoginPanel(Tacebook app) {
        this.app = app;
        setLayout(new BorderLayout());
        
        // Create title panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(59, 89, 152)); // Facebook blue
        JLabel titleLabel = new JLabel("Tacebook");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 36));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);
        
        // Create login form panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Username field
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Username:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        usernameField = new JTextField(20);
        formPanel.add(usernameField, gbc);
        
        // Password field
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.0;
        formPanel.add(new JLabel("Password:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.weightx = 1.0;
        passwordField = new JPasswordField(20);
        formPanel.add(passwordField, gbc);
        
        // Buttons panel
        JPanel buttonPanel = new JPanel();
        loginButton = new JButton("Login");
        registerButton = new JButton("Register");
        
        loginButton.addActionListener(e -> login());
        registerButton.addActionListener(e -> app.showRegisterPanel());
        
        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);
        
        // Add components to main panel
        add(titlePanel, BorderLayout.NORTH);
        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    private void login() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both username and password", 
                                         "Login Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (app.login(username, password)) {
            // Clear fields
            usernameField.setText("");
            passwordField.setText("");
            
            // Show news feed
            app.showNewsFeedPanel();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password", 
                                         "Login Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}