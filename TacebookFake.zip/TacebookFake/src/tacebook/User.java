package tacebook;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a user in the Tacebook social media application
 */
public class User {
    private String username;
    private String password;
    private String fullName;
    private String email;
    private List<User> friends;
    private List<Post> posts;
    
    public User(String username, String password, String fullName, String email) {
        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.email = email;
        this.friends = new ArrayList<>();
        this.posts = new ArrayList<>();
    }
    
    public boolean checkPassword(String password) {
        return this.password.equals(password);
    }
    
    public void addFriend(User friend) {
        if (!friends.contains(friend) && friend != this) {
            friends.add(friend);
        }
    }
    
    public void removeFriend(User friend) {
        friends.remove(friend);
    }
    
    public void addPost(Post post) {
        posts.add(post);
    }
    
    public List<Post> getPosts() {
        return posts;
    }
    
    public List<User> getFriends() {
        return friends;
    }
    
    public String getUsername() {
        return username;
    }
    
    public String getFullName() {
        return fullName;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    @Override
    public String toString() {
        return fullName + " (@" + username + ")";
    }
}