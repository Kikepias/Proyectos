package tacebook;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Panel for displaying and editing user profile in the Tacebook application
 */
public class ProfilePanel extends JPanel {
    private Tacebook app;
    private JLabel usernameLabel;
    private JTextField fullNameField;
    private JTextField emailField;
    private JButton saveButton;
    private JButton cancelButton;
    private JTextArea postsArea;
    private JButton newPostButton;
    private JButton backButton;
    
    public ProfilePanel(Tacebook app) {
        this.app = app;
        setLayout(new BorderLayout());
        
        // Create title panel
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(new Color(59, 89, 152)); // Facebook blue
        JLabel titleLabel = new JLabel("Profile");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel, BorderLayout.CENTER);
        
        // Create navigation panel
        JPanel navPanel = new JPanel();
        navPanel.setBackground(new Color(59, 89, 152));
        JButton homeButton = new JButton("Home");
        JButton friendsButton = new JButton("Friends");
        JButton logoutButton = new JButton("Logout");
        
        homeButton.addActionListener(e -> app.showNewsFeedPanel());
        friendsButton.addActionListener(e -> app.showFriendsPanel());
        logoutButton.addActionListener(e -> app.logout());
        
        navPanel.add(homeButton);
        navPanel.add(friendsButton);
        navPanel.add(logoutButton);
        titlePanel.add(navPanel, BorderLayout.SOUTH);
        
        // Create profile info panel
        JPanel infoPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Username (non-editable)
        gbc.gridx = 0;
        gbc.gridy = 0;
        infoPanel.add(new JLabel("Username:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        usernameLabel = new JLabel();
        infoPanel.add(usernameLabel, gbc);
        
        // Full Name field
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.0;
        infoPanel.add(new JLabel("Full Name:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.weightx = 1.0;
        fullNameField = new JTextField(20);
        infoPanel.add(fullNameField, gbc);
        
        // Email field
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0.0;
        infoPanel.add(new JLabel("Email:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.weightx = 1.0;
        emailField = new JTextField(20);
        infoPanel.add(emailField, gbc);
        
        // Buttons panel
        JPanel buttonPanel = new JPanel();
        saveButton = new JButton("Save Changes");
        cancelButton = new JButton("Cancel");
        
        saveButton.addActionListener(e -> saveProfile());
        cancelButton.addActionListener(e -> updateProfile()); // Reset to current values
        
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        
        // Posts panel
        JPanel postsPanel = new JPanel(new BorderLayout());
        postsPanel.setBorder(BorderFactory.createTitledBorder("My Posts"));
        
        postsArea = new JTextArea();
        postsArea.setEditable(false);
        postsArea.setLineWrap(true);
        postsArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(postsArea);
        scrollPane.setPreferredSize(new Dimension(400, 200));
        
        newPostButton = new JButton("New Post");
        newPostButton.addActionListener(e -> createNewPost());
        
        postsPanel.add(scrollPane, BorderLayout.CENTER);
        postsPanel.add(newPostButton, BorderLayout.SOUTH);
        
        // Main content panel
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.add(infoPanel, BorderLayout.NORTH);
        contentPanel.add(buttonPanel, BorderLayout.CENTER);
        contentPanel.add(postsPanel, BorderLayout.SOUTH);
        
        // Add components to main panel
        add(titlePanel, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);
    }
    
    public void updateProfile() {
        User currentUser = app.getCurrentUser();
        if (currentUser != null) {
            usernameLabel.setText(currentUser.getUsername());
            fullNameField.setText(currentUser.getFullName());
            emailField.setText(currentUser.getEmail());
            
            // Update posts
            StringBuilder sb = new StringBuilder();
            for (Post post : currentUser.getPosts()) {
                sb.append(post.toString()).append("\n\n");
            }
            postsArea.setText(sb.toString());
        }
    }
    
    private void saveProfile() {
        User currentUser = app.getCurrentUser();
        if (currentUser != null) {
            currentUser.setFullName(fullNameField.getText());
            currentUser.setEmail(emailField.getText());
            JOptionPane.showMessageDialog(this, "Profile updated successfully");
        }
    }
    
    private void createNewPost() {
        String content = JOptionPane.showInputDialog(this, "What's on your mind?");
        if (content != null && !content.trim().isEmpty()) {
            User currentUser = app.getCurrentUser();
            Post post = new Post(content, currentUser);
            currentUser.addPost(post);
            updateProfile(); // Refresh posts
        }
    }
}