package tacebook;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Main application class for Tacebook - a simple social media application
 */
public class Tacebook {
    private JFrame mainFrame;
    private CardLayout cardLayout;
    private JPanel mainPanel;
    
    // Current logged in user
    private User currentUser;
    
    // Panels for different screens
    private LoginPanel loginPanel;
    private RegisterPanel registerPanel;
    private ProfilePanel profilePanel;
    private NewsFeedPanel newsFeedPanel;
    private FriendsPanel friendsPanel;
    
    // Database to store users and posts
    private UserDatabase userDatabase;
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new Tacebook().initialize();
        });
    }
    
    public Tacebook() {
        userDatabase = new UserDatabase();
        // Add some sample data
        addSampleData();
    }
    
    private void initialize() {
        // Create main frame
        mainFrame = new JFrame("Tacebook");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(800, 600);
        mainFrame.setLocationRelativeTo(null);
        
        // Create card layout for switching between panels
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        
        // Initialize panels
        loginPanel = new LoginPanel(this);
        registerPanel = new RegisterPanel(this);
        profilePanel = new ProfilePanel(this);
        newsFeedPanel = new NewsFeedPanel(this);
        friendsPanel = new FriendsPanel(this);
        
        // Add panels to main panel
        mainPanel.add(loginPanel, "login");
        mainPanel.add(registerPanel, "register");
        mainPanel.add(profilePanel, "profile");
        mainPanel.add(newsFeedPanel, "newsfeed");
        mainPanel.add(friendsPanel, "friends");
        
        // Show login panel first
        cardLayout.show(mainPanel, "login");
        
        mainFrame.add(mainPanel);
        mainFrame.setVisible(true);
    }
    
    private void addSampleData() {
        // Add sample users
        User user1 = new User("john", "password", "John Smith", "john@example.com");
        User user2 = new User("jane", "password", "Jane Doe", "jane@example.com");
        User user3 = new User("bob", "password", "Bob Johnson", "bob@example.com");
        
        userDatabase.addUser(user1);
        userDatabase.addUser(user2);
        userDatabase.addUser(user3);
        
        // Add sample posts
        user1.addPost(new Post("Hello world! This is my first post on Tacebook."));
        user2.addPost(new Post("I love this new social media platform!"));
        user3.addPost(new Post("Anyone want to connect? I'm new here."));
        
        // Add sample friends
        user1.addFriend(user2);
        user2.addFriend(user1);
        user2.addFriend(user3);
        user3.addFriend(user2);
    }
    
    // Methods to switch between panels
    public void showLoginPanel() {
        cardLayout.show(mainPanel, "login");
    }
    
    public void showRegisterPanel() {
        cardLayout.show(mainPanel, "register");
    }
    
    public void showProfilePanel() {
        profilePanel.updateProfile();
        cardLayout.show(mainPanel, "profile");
    }
    
    public void showNewsFeedPanel() {
        newsFeedPanel.updateFeed();
        cardLayout.show(mainPanel, "newsfeed");
    }
    
    public void showFriendsPanel() {
        friendsPanel.updateFriendsList();
        cardLayout.show(mainPanel, "friends");
    }
    
    // Login method
    public boolean login(String username, String password) {
        User user = userDatabase.getUser(username);
        if (user != null && user.checkPassword(password)) {
            currentUser = user;
            return true;
        }
        return false;
    }
    
    // Register method
    public boolean register(String username, String password, String fullName, String email) {
        if (userDatabase.getUser(username) != null) {
            return false; // Username already exists
        }
        
        User newUser = new User(username, password, fullName, email);
        userDatabase.addUser(newUser);
        currentUser = newUser;
        return true;
    }
    
    // Logout method
    public void logout() {
        currentUser = null;
        showLoginPanel();
    }
    
    // Getters
    public User getCurrentUser() {
        return currentUser;
    }
    
    public UserDatabase getUserDatabase() {
        return userDatabase;
    }
}