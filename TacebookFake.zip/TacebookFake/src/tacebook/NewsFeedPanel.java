package tacebook;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

/**
 * Panel for displaying the news feed in the Tacebook application
 */
public class NewsFeedPanel extends JPanel {
    private Tacebook app;
    private JTextArea feedArea;
    private JTextField postField;
    private JButton postButton;
    
    public NewsFeedPanel(Tacebook app) {
        this.app = app;
        setLayout(new BorderLayout());
        
        // Create title panel
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(new Color(59, 89, 152)); // Facebook blue
        JLabel titleLabel = new JLabel("News Feed");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel, BorderLayout.CENTER);
        
        // Create navigation panel
        JPanel navPanel = new JPanel();
        navPanel.setBackground(new Color(59, 89, 152));
        JButton profileButton = new JButton("Profile");
        JButton friendsButton = new JButton("Friends");
        JButton logoutButton = new JButton("Logout");
        
        profileButton.addActionListener(e -> app.showProfilePanel());
        friendsButton.addActionListener(e -> app.showFriendsPanel());
        logoutButton.addActionListener(e -> app.logout());
        
        navPanel.add(profileButton);
        navPanel.add(friendsButton);
        navPanel.add(logoutButton);
        titlePanel.add(navPanel, BorderLayout.SOUTH);
        
        // Create feed panel
        JPanel feedPanel = new JPanel(new BorderLayout());
        feedArea = new JTextArea();
        feedArea.setEditable(false);
        feedArea.setLineWrap(true);
        feedArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(feedArea);
        scrollPane.setPreferredSize(new Dimension(400, 300));
        feedPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Create post panel
        JPanel postPanel = new JPanel(new BorderLayout());
        postField = new JTextField();
        postButton = new JButton("Post");
        
        postButton.addActionListener(e -> createPost());
        
        postPanel.add(new JLabel("What's on your mind?"), BorderLayout.NORTH);
        postPanel.add(postField, BorderLayout.CENTER);
        postPanel.add(postButton, BorderLayout.EAST);
        
        // Add components to main panel
        add(titlePanel, BorderLayout.NORTH);
        add(feedPanel, BorderLayout.CENTER);
        add(postPanel, BorderLayout.SOUTH);
    }
    
    private void createPost() {
        String content = postField.getText().trim();
        if (!content.isEmpty()) {
            User currentUser = app.getCurrentUser();
            Post post = new Post(content, currentUser);
            currentUser.addPost(post);
            postField.setText("");
            updateFeed();
        }
    }
    
    public void updateFeed() {
        feedArea.setText("");
        User currentUser = app.getCurrentUser();
        
        // Add posts from current user and friends
        StringBuilder sb = new StringBuilder();
        
        // Add current user's posts
        for (Post post : currentUser.getPosts()) {
            sb.append(post.toString()).append("\n\n");
        }
        
        // Add friends' posts
        for (User friend : currentUser.getFriends()) {
            for (Post post : friend.getPosts()) {
                sb.append(post.toString()).append("\n\n");
            }
        }
        
        feedArea.setText(sb.toString());
    }
}