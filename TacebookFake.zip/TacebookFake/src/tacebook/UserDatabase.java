package tacebook;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Database class to store and manage users in the Tacebook application
 */
public class UserDatabase {
    private Map<String, User> users;
    
    public UserDatabase() {
        users = new HashMap<>();
    }
    
    public void addUser(User user) {
        users.put(user.getUsername(), user);
    }
    
    public User getUser(String username) {
        return users.get(username);
    }
    
    public List<User> getAllUsers() {
        return new ArrayList<>(users.values());
    }
    
    public List<User> searchUsers(String query) {
        List<User> results = new ArrayList<>();
        String lowerQuery = query.toLowerCase();
        
        for (User user : users.values()) {
            if (user.getUsername().toLowerCase().contains(lowerQuery) ||
                user.getFullName().toLowerCase().contains(lowerQuery)) {
                results.add(user);
            }
        }
        
        return results;
    }
}