/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui;

import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

/**
 *
 * @author pedri
 * Implementamos o WordGenerator na nova clase 
 */
public class GUIKeyboardWordGenerator implements WordGenerator{
@Override
    public String generateWord() throws GenerateWordException {
        JPasswordField passwordField = new JPasswordField();
        Object[] message = {"Introduce a palabra oculta:", passwordField};
        
        int option = JOptionPane.showConfirmDialog(
                null,
                message,
                "Entrada de palabra oculta",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );

        if (option != JOptionPane.OK_OPTION) {
            throw new GenerateWordException("Operación cancelada polo usuario", false);
        }

        String word = new String(passwordField.getPassword());

        if (!isValid(word)) {
            JOptionPane.showMessageDialog(
                    null,
                    "A palabra só pode conter letras minúsculas de 'a' a 'z'.",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE
            );
            return generateWord(); // Volvemos a pedir a palabra
        }

        return word;
    }

    private boolean isValid(String word) {
        return word.matches("[a-z]+"); // Comprueba que solo contenga letras minúsculas
    }
}
