package teistris3;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.BorderFactory;
import javax.swing.border.BevelBorder;

public class Square3 {
    private int x, y;
    private JLabel lblSquare;
    private Color fillColor;

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
        lblSquare.setBounds(x, y, Game3.SQUARE_SIDE, Game3.SQUARE_SIDE);
        lblSquare.repaint();
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
        lblSquare.setBounds(x, y, Game3.SQUARE_SIDE, Game3.SQUARE_SIDE);
        lblSquare.repaint();
    }

    public String getCoordinates() {
        return x + "," + y;
    }

    public JLabel getLblSquare() {
        return lblSquare;
    }

    public Color getFillColor() {
        return fillColor;
    }

    public void setFillColor(Color fillColor) {
        this.fillColor = fillColor;
        lblSquare.setBackground(fillColor);
        lblSquare.repaint();
    }

    public Square3(int x, int y, Color fillColor, Game3 game) {
        this.x = x;
        this.y = y;
        this.fillColor = fillColor;

        lblSquare = new JLabel();
        lblSquare.setBackground(fillColor);
        lblSquare.setBounds(x, y, Game3.SQUARE_SIDE, Game3.SQUARE_SIDE);
        lblSquare.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        lblSquare.setVisible(true);
        lblSquare.setOpaque(true);

        game.getMainWindow().drawSquare(this.lblSquare);
    }
}