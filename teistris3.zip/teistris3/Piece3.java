package teistris3;

import java.awt.Color;

public abstract class Piece3 {
    protected Game3 game;
    protected Square3[] squares;

    public Piece3(Game3 game) {
        this.game = game;
        squares = new Square3[4];
    }

    public Square3[] getSquares() {
        return squares;
    }

    public boolean moveRight() {
        for (Square3 square : squares) {
            if (!game.isValidPosition(square.getX() + Game3.SQUARE_SIDE, square.getY())) {
                return false;
            }
        }
        
        for (Square3 square : squares) {
            square.setX(square.getX() + Game3.SQUARE_SIDE);
        }
        return true;
    }

    public boolean moveLeft() {
        for (Square3 square : squares) {
            if (!game.isValidPosition(square.getX() - Game3.SQUARE_SIDE, square.getY())) {
                return false;
            }
        }
        
        for (Square3 square : squares) {
            square.setX(square.getX() - Game3.SQUARE_SIDE);
        }
        return true;
    }

    public boolean moveDown() {
        for (Square3 square : squares) {
            if (!game.isValidPosition(square.getX(), square.getY() + Game3.SQUARE_SIDE)) {
                return false;
            }
        }
        
        for (Square3 square : squares) {
            square.setY(square.getY() + Game3.SQUARE_SIDE);
        }
        return true;
    }

    public abstract boolean rotate();
}