package teistris3;

import java.util.HashMap;
import java.util.Map;

public class Game3 {
    public final static int SQUARE_SIDE = 20;
    public final static int MAX_X = 160;
    public final static int MAX_Y = 200;

    private Piece3 currentPiece;
    private MainWindow3 mainWindow;
    private boolean paused = false;
    private int numberOfLines = 0;
    private Map<String, Square3> groundSquares;

    public Game3(MainWindow3 mainWindow) {
        this.mainWindow = mainWindow;
        this.groundSquares = new HashMap<>();
        this.createNewPiece();
    }

    public MainWindow3 getMainWindow() {
        return mainWindow;
    }

    public void setMainWindow(MainWindow3 mainWindow) {
        this.mainWindow = mainWindow;
    }

    public boolean isPaused() {
        return paused;
    }

    public void setPaused(boolean paused) {
        this.paused = paused;
    }

    public int getNumberOfLines() {
        return numberOfLines;
    }

    public void setNumberOfLines(int numberOfLines) {
        this.numberOfLines = numberOfLines;
    }

    public Piece3 getCurrentPiece() {
        return currentPiece;
    }

    public boolean isValidPosition(int x, int y) {
        if ((x == MAX_X) || (x < 0) || (y == MAX_Y) || (y < 0)) {
            return false;
        }
        String coordinates = x + "," + y;
        return !groundSquares.containsKey(coordinates);
    }

    private void addPieceToGround() {
        for (Square3 square : currentPiece.getSquares()) {
            groundSquares.put(square.getCoordinates(), square);
        }
        this.deleteCompletedLines();
    }

    private void deleteCompletedLines() {
        for (int y = 0; y < MAX_Y; y += SQUARE_SIDE) {
            int squaresInLine = 0;
            for (int x = 0; x < MAX_X; x += SQUARE_SIDE) {
                if (groundSquares.containsKey(x + "," + y)) {
                    squaresInLine++;
                }
            }
            if (squaresInLine == MAX_X / SQUARE_SIDE) {
                deleteLine(y);
                numberOfLines++;
                mainWindow.showNumberOfLines(numberOfLines);
            }
        }
    }

    private void deleteLine(int y) {
        for (int x = 0; x < MAX_X; x += SQUARE_SIDE) {
            String coordinates = x + "," + y;
            Square3 square = groundSquares.remove(coordinates);
            if (square != null) {
                mainWindow.deleteSquare(square.getLblSquare());
            }
        }

        Map<String, Square3> newGroundSquares = new HashMap<>();
        for (Map.Entry<String, Square3> entry : groundSquares.entrySet()) {
            Square3 square = entry.getValue();
            if (square.getY() < y) {
                square.setY(square.getY() + SQUARE_SIDE);
                newGroundSquares.put(square.getCoordinates(), square);
            } else {
                newGroundSquares.put(entry.getKey(), square);
            }
        }
        groundSquares = newGroundSquares;
    }

    private boolean hitPieceTheGround() {
        for (Square3 square : currentPiece.getSquares()) {
            String coordinates = square.getCoordinates();
            if (groundSquares.containsKey(coordinates)) {
                return true;
            }
        }
        return false;
    }

    private void createNewPiece() {
        int pieceType = new java.util.Random().nextInt(2);
        switch(pieceType) {
            case 0:
                currentPiece = new LinePiece3(this);
                break;
            case 1:
                currentPiece = new SquarePiece3(this);
                break;
        }
    }
}