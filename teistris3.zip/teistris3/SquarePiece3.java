package teistris3;

import java.awt.Color;

public class SquarePiece3 extends Piece3 {
    public SquarePiece3(Game3 game) {
        super(game);
        squares[0] = new Square3(Game3.MAX_X / 2, 0, Color.YELLOW, game);
        squares[1] = new Square3(Game3.MAX_X / 2 + Game3.SQUARE_SIDE, 0, Color.YELLOW, game);
        squares[2] = new Square3(Game3.MAX_X / 2, Game3.SQUARE_SIDE, Color.YELLOW, game);
        squares[3] = new Square3(Game3.MAX_X / 2 + Game3.SQUARE_SIDE, Game3.SQUARE_SIDE, Color.YELLOW, game);
    }

    @Override
    public boolean rotate() {
        // Square piece doesn't need rotation as it looks the same in all orientations
        return true;
    }
}