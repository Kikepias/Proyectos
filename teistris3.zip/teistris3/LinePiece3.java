package teistris3;

import java.awt.Color;

public class LinePiece3 extends Piece3 {
    public LinePiece3(Game3 game) {
        super(game);
        squares[0] = new Square3(Game3.MAX_X / 2, 0, Color.CYAN, game);
        squares[1] = new Square3(Game3.MAX_X / 2, Game3.SQUARE_SIDE, Color.CYAN, game);
        squares[2] = new Square3(Game3.MAX_X / 2, Game3.SQUARE_SIDE * 2, Color.CYAN, game);
        squares[3] = new Square3(Game3.MAX_X / 2, Game3.SQUARE_SIDE * 3, Color.CYAN, game);
    }

    @Override
    public boolean rotate() {
        boolean isVertical = squares[0].getX() == squares[1].getX();
        int x = squares[1].getX();
        int y = squares[1].getY();

        if (isVertical) {
            // Check if horizontal rotation is possible
            for (int i = -1; i <= 2; i++) {
                if (!game.isValidPosition(x + i * Game3.SQUARE_SIDE, y)) {
                    return false;
                }
            }
            // Rotate to horizontal
            squares[0].setX(x - Game3.SQUARE_SIDE);
            squares[0].setY(y);
            squares[2].setX(x + Game3.SQUARE_SIDE);
            squares[2].setY(y);
            squares[3].setX(x + 2 * Game3.SQUARE_SIDE);
            squares[3].setY(y);
        } else {
            // Check if vertical rotation is possible
            for (int i = -1; i <= 2; i++) {
                if (!game.isValidPosition(x, y + i * Game3.SQUARE_SIDE)) {
                    return false;
                }
            }
            // Rotate to vertical
            squares[0].setX(x);
            squares[0].setY(y - Game3.SQUARE_SIDE);
            squares[2].setX(x);
            squares[2].setY(y + Game3.SQUARE_SIDE);
            squares[3].setX(x);
            squares[3].setY(y + 2 * Game3.SQUARE_SIDE);
        }
        return true;
    }
}