/*
 * Copyright (C) 2019 Antonio de Andrés Lema
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package tetris.model;

import java.awt.Color;

/**
 * Clase que implementa a peza cadrada do xogo do Tetris
 *
 * @author Profe de Programación
 */
public abstract class Piece {

    /**
     * Referenza ao obxecto xogo
     */
    protected Game game;

    /**
     * Array de referenzas aos catro cadrados que forman a peza
     */
    protected Square[] squares;

    /**
     * Construtor da clase, que inicializa o xogo e o array de cadrados
     */
    public Piece(Game game) {
        this.game = game;
        
        // Inicializamos o array de cadrados
        squares = new Square[4];
    }

    /**
     * Move a ficha á dereita se é posible
     *
     * @return true se o movemento da ficha é posible, se non false
     */
    public boolean moveRight() {
        // Comprobamos se é posible mover a ficha á dereita
        boolean canMove = true;
        
        // Verificamos que todos os cadrados poidan moverse á dereita
        for (Square square : squares) {
            if (!game.isValidPosition(square.getX() + Game.SQUARE_SIDE, square.getY())) {
                canMove = false;
                break;
            }
        }
        
        if (canMove) {
            // Movemos os cadrados á dereita
            for (Square square : squares) {
                square.setX(square.getX() + Game.SQUARE_SIDE);
            }
            return true;
        }
        return false;
    }

    /**
     * Move a ficha á esquerda se é posible
     *
     * @return true se o movemento da ficha é posible, se non false
     */
    public boolean moveLeft() {
        // Comprobamos se é posible mover a ficha á esquerda
        boolean canMove = true;
        
        // Verificamos que todos os cadrados poidan moverse á esquerda
        for (Square square : squares) {
            if (!game.isValidPosition(square.getX() - Game.SQUARE_SIDE, square.getY())) {
                canMove = false;
                break;
            }
        }
        
        if (canMove) {
            // Movemos os cadrados á esquerda
            for (Square square : squares) {
                square.setX(square.getX() - Game.SQUARE_SIDE);
            }
            return true;
        }
        return false;
    }

    /**
     * Move a ficha a abaixo se é posible
     *
     * @return true se o movemento da ficha é posible, se non false
     */
    public boolean moveDown() {
        // Comprobamos se é posible mover a ficha abaixo
        boolean canMove = true;
        
        // Verificamos que todos os cadrados poidan moverse abaixo
        for (Square square : squares) {
            if (!game.isValidPosition(square.getX(), square.getY() + Game.SQUARE_SIDE)) {
                canMove = false;
                break;
            }
        }
        
        if (canMove) {
            // Movemos os cadrados abaixo
            for (Square square : squares) {
                square.setY(square.getY() + Game.SQUARE_SIDE);
            }
            return true;
        }
        return false;
    }

    /**
     * Rota a ficha se é posible
     *
     * @return true se o movemento da ficha é posible, se non false
     */
    public abstract boolean rotate();

    /**
     * @return Referenza ao obxecto xogo
     */
    public Game getGame() {
        return game;
    }

    /**
     * @param game Referenza ao obxecto xogo a establecer
     */
    public void setGame(Game game) {
        this.game = game;
    }

    /**
     * @return Array de referenzas aos cadrados que forman a peza
     */
    public Square[] getSquares() {
        return squares;
    }
}