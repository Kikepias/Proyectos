/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tetris.model;

/**
 *
 * @author Enrique
 */
import java.awt.Color;

/**
 * Clase que implementa a peza en forma de barra do xogo do Tetris
 *
 * @author Profe de Programación
 */
public class BarPiece extends Piece {
    
    // Posición actual da peza (0: horizontal, 1: vertical)
    private int position = 0;

    /**
     * Construtor da clase, que crea os catro cadrados que forman a peza en barra
     */
    public BarPiece(Game game) {
        super(game);
        
        // Creamos os catro cadrados que forman a peza en barra (posición horizontal)
        squares[0] = new Square(Game.MAX_X / 2 - Game.SQUARE_SIDE * 2, 0, Color.CYAN, game);
        squares[1] = new Square(Game.MAX_X / 2 - Game.SQUARE_SIDE, 0, Color.CYAN, game);
        squares[2] = new Square(Game.MAX_X / 2, 0, Color.CYAN, game);
        squares[3] = new Square(Game.MAX_X / 2 + Game.SQUARE_SIDE, 0, Color.CYAN, game);
    }

    /**
     * Rota a ficha se é posible
     *
     * @return true se o movemento da ficha é posible, se non false
     */
    @Override
    public boolean rotate() {
        // Calculamos a nova posición
        int newPosition = (position + 1) % 2;
        
        // Gardamos as posicións actuais dos cadrados
        int[] xPos = new int[4];
        int[] yPos = new int[4];
        
        for (int i = 0; i < 4; i++) {
            xPos[i] = squares[i].getX();
            yPos[i] = squares[i].getY();
        }
        
        // Calculamos as novas posicións segundo a rotación
        // Usamos o segundo cadrado como centro de rotación
        int centerX = squares[1].getX();
        int centerY = squares[1].getY();
        
        int[][] newPositions = new int[4][2];
        
        switch (newPosition) {
            case 0: // Posición horizontal
                newPositions[0][0] = centerX - Game.SQUARE_SIDE;
                newPositions[0][1] = centerY;
                newPositions[1][0] = centerX;
                newPositions[1][1] = centerY;
                newPositions[2][0] = centerX + Game.SQUARE_SIDE;
                newPositions[2][1] = centerY;
                newPositions[3][0] = centerX + Game.SQUARE_SIDE * 2;
                newPositions[3][1] = centerY;
                break;
            case 1: // Posición vertical
                newPositions[0][0] = centerX;
                newPositions[0][1] = centerY - Game.SQUARE_SIDE;
                newPositions[1][0] = centerX;
                newPositions[1][1] = centerY;
                newPositions[2][0] = centerX;
                newPositions[2][1] = centerY + Game.SQUARE_SIDE;
                newPositions[3][0] = centerX;
                newPositions[3][1] = centerY + Game.SQUARE_SIDE * 2;
                break;
        }
        
        // Comprobamos se as novas posicións son válidas
        for (int i = 0; i < 4; i++) {
            if (!game.isValidPosition(newPositions[i][0], newPositions[i][1])) {
                return false; // Non podemos rotar
            }
        }
        
        // Aplicamos a rotación
        for (int i = 0; i < 4; i++) {
            squares[i].setX(newPositions[i][0]);
            squares[i].setY(newPositions[i][1]);
        }
        
        // Actualizamos a posición actual
        position = newPosition;
        
        return true;
    }
}
