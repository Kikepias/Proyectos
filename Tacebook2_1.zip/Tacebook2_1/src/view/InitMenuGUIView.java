/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import controller.InitMenuController;
import javax.swing.JOptionPane;

/**
 *
 * @author pedri
 */
public class InitMenuGUIView implements ViewInterface{
   private InitMenuController controller;

    public InitMenuGUIView(InitMenuController controller) {
        this.controller = controller;
    }

    @Override
    public boolean showLoginMenu() {
        System.out.println("=== MENÚ DE LOGIN - Versión GUI ===");
        return false;
    }

    @Override
    public void showLoginErrorMessage() {
        System.out.println("Erro: Usuario ou contrasinal incorrectos. [Versión GUI]");
    }

    public void showConnectionErrorMessage() {
        System.out.println("Erro de conexión coa base de datos. [Versión GUI]");
    }

    public void showReadErrorMessage() {
        System.out.println("Erro ao ler datos. [Versión GUI]");
    }

    public void showWriteErrorMessage() {
        System.out.println("Erro ao escribir datos. [Versión GUI]");
    }

    @Override
    public String showNewNameMenu() {
        System.out.println("Este nome xa existe. Introduza un novo nome: [Versión GUI]");
        return "NovoNomeGUI";
    }

    @Override
    public void showRegisterMenu() {
        System.out.println("=== MENÚ DE REGISTRO - Versión GUI ===");
    }
}
