/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package view;

/**
 *
 * @author pedri
 */
public interface ViewInterface {
     // Muestra el menú de inicio de sesión y devuelve true si el usuario desea salir
    boolean showLoginMenu();
    
    // Muestra un mensaje de error en caso de que el inicio de sesión falle
    void showLoginErrorMessage();
    
    // Muestra el menú de registro de usuario
    void showRegisterMenu();
    
    // Muestra un mensaje pidiendo un nuevo nombre de usuario si el actual ya está en uso
    String showNewNameMenu();
}
