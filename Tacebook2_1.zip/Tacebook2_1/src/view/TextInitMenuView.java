/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import controller.InitMenuController;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import persistence.PersistenceException;

/**
 *
 * @author fernando.pedridomarino
 */
public class TextInitMenuView implements InitMenuView{
      private InitMenuController controller;

    public TextInitMenuView(InitMenuController controller) {
        this.controller = controller;
    }

    @Override
    public boolean showLoginMenu() {
        System.out.println("=== MENÚ DE LOGIN ===");
        // Aquí iría a lóxica para mostrar o menú e obter entrada do usuario
        return false;
    }

    @Override
    public void showLoginErrorMessage() {
        System.out.println("Erro: Usuario ou contrasinal incorrectos.");
    }

    @Override
    public void showConnectionErrorMessage() {
        System.out.println("Erro de conexión coa base de datos.");
    }

    @Override
    public void showReadErrorMessage() {
        System.out.println("Erro ao ler datos.");
    }

    @Override
    public void showWriteErrorMessage() {
        System.out.println("Erro ao escribir datos.");
    }

    @Override
    public String showNewNameMenu() {
        System.out.println("Este nome xa existe. Introduza un novo nome:");
        // Aquí debería capturar entrada do usuario
        return "NovoNome";
    }

    @Override
    public void showRegisterMenu() {
        System.out.println("=== MENÚ DE REGISTRO ===");
    }
}

