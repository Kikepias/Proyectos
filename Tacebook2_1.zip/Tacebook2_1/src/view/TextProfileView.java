/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import controller.ProfileController;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Profile;
import persistence.PersistenceException;

/**
 *
 * @author fernando.pedridomarino
 */
public class TextProfileView implements ProfileView{
    
      private ProfileController profileController;
    private final ProfileController ProfileController;

    // Constructor que recibe el controlador del perfil
    public TextProfileView () {
        this.ProfileController = profileController;
    }

    private TextProfileView(ProfileController profileController) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Método para leer números de forma segura
    private int readNumber(Scanner scanner) {
        while (true) {
            try {
                int number = scanner.nextInt();
                scanner.nextLine(); // Limpiar el salto de línea
                return number;
            } catch (NoSuchElementException e) {
                System.out.println("Debe introducir un número válido. Inténtelo de nuevo.");
                scanner.nextLine(); // Limpiar el buffer de entrada
            }
        }
    }

    // Método para mostrar el menú de perfil

    /**
     *
     * @throws Exception
     */
      @Override
    public void showProfileMenu(){
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            // Mostrar opciones del menú de perfil
            System.out.println("Menú de Perfil");
            System.out.println("1. Ver detalles del perfil");
            System.out.println("2. Editar perfil");
            System.out.println("3. Eliminar perfil");
            System.out.println("4. Salir");
            System.out.print("Seleccione unha opción: ");
            
            // Usamos el método readNumber para obtener la opción
            int option = readNumber(scanner);

            // Llamada a la opción seleccionada
            switch (option) {
                case 1:
                    showProfileDetails();
                    break;
                case 2:
                {
                    try {
                        editProfile();
                    } catch (Exception ex) {
                        Logger.getLogger(TextProfileView.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                    break;

                case 3:
                    deleteProfile();
                    break;
                case 4:
                    exit = true;
                    System.out.println("Saíndo do menú de perfil...");
                    break;
                default:
                    System.out.println("Opción non válida.");
            }
        }
    }

    // Método para mostrar los detalles del perfil
    private void showProfileDetails() {
        System.out.println("Detalles do perfil:");
        // Aquí iría el código para mostrar los detalles del perfil, como el nombre y la edad
        // Esta parte es un ejemplo, ya que no tenemos acceso a los datos del perfil aún.
        System.out.println("Nome: [Nombre del Usuario]");
        System.out.println("Idade: [Edad del Usuario]");
        System.out.println("Estado: [Estado del Usuario]");
    }

    // Método para editar el perfil
    private void editProfile() throws Exception {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Editar Perfil:");
        
        // Ejemplo de cómo editar el nombre
        System.out.print("Introduce un novo nome: ");
        String newName = scanner.nextLine();
        
        profileController.updateProfileName(newName);  // Llamada al controlador para actualizar el perfil
        System.out.println("Nome actualizado a: " + newName);
    }

    // Método para eliminar el perfil
    private void deleteProfile() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Eliminar Perfil:");
        System.out.print("Está seguro de que desexa eliminar o seu perfil? (1 = Si, 2 = Non): ");
        
        int confirm = readNumber(scanner);

        if (confirm == 1) {
            profileController.deleteProfile();  // Llamada al controlador para eliminar el perfil
            System.out.println("Perfil eliminado.");
        } else {
            System.out.println("Perfil non eliminado.");
        }
    }

    // Método para manejar las excepciones de persistencia
    private void handlePersistenceException(PersistenceException e) {
        switch (e.getCode()) {
            case PersistenceException.CONNECTION_ERROR:
                showConnectionErrorMessage();
                break;
            case PersistenceException.CANNOT_READ:
                showReadErrorMessage();
                break;
            case PersistenceException.CANNOT_WRITE:
                showWriteErrorMessage();
                break;
            default:
                System.out.println("Erro descoñecido na persistencia.");
        }
    }

    // Métodos para mostrar los mensajes de error
    public void showConnectionErrorMessage() {
        System.out.println("Erro na conexión co almacén de datos!");
    }

    public void showReadErrorMessage() {
        System.out.println("Erro na lectura de datos!");
    }

    public void showWriteErrorMessage() {
        System.out.println("Erro na escritura dos datos!");
    }

    // Método principal para simular la interacción con el usuario
    public static void main(String[] args) {
        // Determinar si el programa se ejecuta en modo texto
        boolean textMode = (args.length > 0 && args[0].equalsIgnoreCase("text"));

        // Inicializamos el controlador con el modo correcto
        ProfileController profileController = new ProfileController(textMode);

        // Seleccionar la implementación de la vista según el modo
        ProfileView profileView;
        if (textMode) {
            profileView = new TextProfileView(profileController);
        } else {
            profileView = new GUIProfileView(profileController);
        }

        // Crear un perfil de prueba
        Profile profile = new Profile("user123", "password123", "Estado de ejemplo");
        profileController.openSession(profile);

        // Mostrar el menú de perfil
        profileView.showProfileMenu(profile);
    }

    @Override
    public int getPostsShowed() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void showProfileMenu(Profile profile) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void showProfileNotFoundMessage() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void showCannotLikeOwnPostMessage() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void showAlreadyLikedPostMessage() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void showIsAlreadyFriendMessage(String profileName) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void showExistsFrienshipRequestMessage(String profileName) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void showDuplicateFrienshipRequestMessage(String profileName) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
