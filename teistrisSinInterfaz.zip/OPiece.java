import java.awt.Color;

public class OPiece extends AbstractPiece {
    public OPiece(int startX, int startY) {
        super(startX, startY);
    }
    
    @Override
    protected Color getColor() {
        return Color.YELLOW;
    }
    
    @Override
    protected int[][] getShape() {
        return new int[][] {{0,0}, {1,0}, {0,1}, {1,1}};
    }
    
    @Override
    protected boolean canRotate() {
        return false; // O piece doesn't rotate
    }
}