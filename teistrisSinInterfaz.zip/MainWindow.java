import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainWindow extends JFrame {
    private static final int BLOCK_SIZE = 30;
    private static final int INITIAL_DELAY = 1000; // 1 second initial delay
    private static final int LINES_FOR_SPEEDUP = 5; // Number of lines needed for speed increase
    
    private boolean isPaused = false;
    private Timer gameTimer;
    private Game game;
    private int currentLevel = 1;
    private int linesCleared = 0;
    private JButton pauseButton;
    private JButton newGameButton;
    private JButton leftButton;
    private JButton rightButton;
    private JButton downButton;
    private JButton rotateButton;
    private JPanel gamePanel;
    
    public MainWindow() {
        setTitle("Simple Tetris");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        
        game = new Game();
        
        // Create game panel
        gamePanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                setBackground(Color.BLACK);
                game.draw(g);
            }
        };
        gamePanel.setPreferredSize(new Dimension(10 * BLOCK_SIZE, 20 * BLOCK_SIZE));
        
        // Create control panel
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new GridLayout(3, 2, 5, 5));
        
        // Initialize buttons
        pauseButton = new JButton("Pause");
        newGameButton = new JButton("New Game");
        leftButton = new JButton("←");
        rightButton = new JButton("→");
        downButton = new JButton("↓");
        rotateButton = new JButton("Rotate");
        
        // Add action listeners
        pauseButton.addActionListener(e -> {
            togglePause();
            requestFocus();
        });
        newGameButton.addActionListener(e -> {
            startNewGame();
            requestFocus();
        });
        leftButton.addActionListener(e -> {
            game.moveLeft();
            gamePanel.repaint();
            requestFocus();
        });
        rightButton.addActionListener(e -> {
            game.moveRight();
            gamePanel.repaint();
            requestFocus();
        });
        downButton.addActionListener(e -> {
            game.moveDown();
            gamePanel.repaint();
            requestFocus();
        });
        rotateButton.addActionListener(e -> {
            game.rotate();
            gamePanel.repaint();
            requestFocus();
        });
        
        // Add buttons to control panel
        controlPanel.add(pauseButton);
        controlPanel.add(newGameButton);
        controlPanel.add(leftButton);
        controlPanel.add(rightButton);
        controlPanel.add(downButton);
        controlPanel.add(rotateButton);
        
        // Set up layout
        setLayout(new BorderLayout());
        add(gamePanel, BorderLayout.CENTER);
        add(controlPanel, BorderLayout.EAST);
        
        // Set up game timer
        gameTimer = new Timer(1000, e -> {
            game.moveDown();
            gamePanel.repaint();
        });
        
        pack();
        setLocationRelativeTo(null);
        
        // Add keyboard controls
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_LEFT:
                        if (!isPaused) {
                            game.moveLeft();
                            gamePanel.repaint();
                        }
                        break;
                    case KeyEvent.VK_RIGHT:
                        if (!isPaused) {
                            game.moveRight();
                            gamePanel.repaint();
                        }
                        break;
                    case KeyEvent.VK_DOWN:
                        if (!isPaused) {
                            game.moveDown();
                            gamePanel.repaint();
                        }
                        break;
                    case KeyEvent.VK_UP:
                        if (!isPaused) {
                            game.rotate();
                            gamePanel.repaint();
                        }
                        break;
                }
            }
        });
        setFocusable(true);
        requestFocus();
        
        // Start the game
        gameTimer.start();
    }
    
    private void togglePause() {
        isPaused = !isPaused;
        if (isPaused) {
            gameTimer.stop();
            pauseButton.setText("Resume");
        } else {
            gameTimer.start();
            pauseButton.setText("Pause");
        }
    }
    
    private void startNewGame() {
        game.reset();
        currentLevel = 1;
        linesCleared = 0;
        if (gameTimer != null) {
            gameTimer.setDelay(INITIAL_DELAY);
        }
        if (!gameTimer.isRunning() && !isPaused) {
            gameTimer.start();
        }
        gamePanel.repaint();
    }
    
    private void checkLinesAndUpdateSpeed() {
        int newLines = game.getScore() / 100; // Since each line is worth 100 points
        if (newLines > linesCleared) {
            linesCleared = newLines;
            if (linesCleared % LINES_FOR_SPEEDUP == 0) {
                currentLevel++;
                int newDelay = INITIAL_DELAY / currentLevel;
                gameTimer.setDelay(Math.max(newDelay, 100)); // Don't go faster than 100ms
            }
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainWindow window = new MainWindow();
            window.setVisible(true);
            window.startNewGame();
        });
    }
}