import java.awt.Color;

public class ZPiece extends AbstractPiece {
    public ZPiece(int startX, int startY) {
        super(startX, startY);
    }
    
    @Override
    protected Color getColor() {
        return Color.RED;
    }
    
    @Override
    protected int[][] getShape() {
        return new int[][] {{-1,0}, {0,0}, {0,1}, {1,1}};
    }
}