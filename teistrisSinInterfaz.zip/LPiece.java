import java.awt.Color;

public class LPiece extends AbstractPiece {
    public LPiece(int startX, int startY) {
        super(startX, startY);
    }
    
    @Override
    protected Color getColor() {
        return Color.ORANGE;
    }
    
    @Override
    protected int[][] getShape() {
        return new int[][] {{-1,0}, {0,0}, {1,0}, {-1,1}};
    }
}