import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

public class Piece {
    private List<Square> squares;
    private int centerX;
    private int centerY;
    private Color color;
    private static final int SQUARE_SIZE = 30;
    private int currentRotation = 0;
    private PieceType type;
    
    public enum PieceType {
        I, O, T, S, Z, J, L
    }
    
    public Piece(int startX, int startY, Color color) {
        this.squares = new ArrayList<>();
        this.centerX = startX;
        this.centerY = startY;
        this.color = color;
        this.type = getRandomPieceType();
        createSquares();
    }
    
    private PieceType getRandomPieceType() {
        PieceType[] types = PieceType.values();
        return types[(int)(Math.random() * types.length)];
    }
    
    private void createSquares() {
        squares.clear();
        int[][] shape = getShapeForType();
        
        for (int[] pos : shape) {
            squares.add(new Square(centerX + pos[0], centerY + pos[1], color, SQUARE_SIZE));
        }
    }
    
    private int[][] getShapeForType() {
        switch (type) {
            case I:
                color = Color.CYAN;
                return new int[][] {{-1,0}, {0,0}, {1,0}, {2,0}};
            case O:
                color = Color.YELLOW;
                return new int[][] {{0,0}, {1,0}, {0,1}, {1,1}};
            case T:
                color = Color.MAGENTA;
                return new int[][] {{0,0}, {-1,0}, {1,0}, {0,1}};
            case S:
                color = Color.GREEN;
                return new int[][] {{0,0}, {1,0}, {-1,1}, {0,1}};
            case Z:
                color = Color.RED;
                return new int[][] {{-1,0}, {0,0}, {0,1}, {1,1}};
            case J:
                color = Color.BLUE;
                return new int[][] {{-1,0}, {0,0}, {1,0}, {1,1}};
            case L:
                color = Color.ORANGE;
                return new int[][] {{-1,0}, {0,0}, {1,0}, {-1,1}};
            default:
                return new int[][] {{0,0}, {1,0}, {0,1}, {1,1}};
        }
    }
    
    public void moveDown() {
        centerY++;
        squares.forEach(Square::moveDown);
    }
    
    public void moveLeft() {
        centerX--;
        squares.forEach(Square::moveLeft);
    }
    
    public void moveRight() {
        centerX++;
        squares.forEach(Square::moveRight);
    }
    
    public void rotate() {
        if (type == PieceType.O) return; // O piece doesn't need rotation
        
        currentRotation = (currentRotation + 1) % 4;
        List<Square> oldSquares = new ArrayList<>(squares);
        squares.clear();
        
        for (Square square : oldSquares) {
            int relX = square.getX() - centerX;
            int relY = square.getY() - centerY;
            
            // Rotate 90 degrees clockwise: (x,y) -> (-y,x)
            int newRelX = -relY;
            int newRelY = relX;
            
            squares.add(new Square(centerX + newRelX, centerY + newRelY, color, SQUARE_SIZE));
        }
    }
    
    public void draw(Graphics g) {
        squares.forEach(square -> {
            g.setColor(square.getColor());
            g.fillRect(square.getX() * SQUARE_SIZE, 
                      square.getY() * SQUARE_SIZE, 
                      square.getSize(), 
                      square.getSize());
            
            // Draw border
            g.setColor(Color.WHITE);
            g.drawRect(square.getX() * SQUARE_SIZE,
                      square.getY() * SQUARE_SIZE,
                      square.getSize(),
                      square.getSize());
        });
    }
    
    public List<Square> getSquares() {
        return squares;
    }
    
    public int getCenterX() { return centerX; }
    public int getCenterY() { return centerY; }
    public PieceType getType() { return type; }
}