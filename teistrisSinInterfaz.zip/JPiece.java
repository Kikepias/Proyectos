import java.awt.Color;

public class JPiece extends AbstractPiece {
    public JPiece(int startX, int startY) {
        super(startX, startY);
    }
    
    @Override
    protected Color getColor() {
        return Color.BLUE;
    }
    
    @Override
    protected int[][] getShape() {
        return new int[][] {{-1,0}, {0,0}, {1,0}, {1,1}};
    }
}