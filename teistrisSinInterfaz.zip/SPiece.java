import java.awt.Color;

public class SPiece extends AbstractPiece {
    public SPiece(int startX, int startY) {
        super(startX, startY);
    }
    
    @Override
    protected Color getColor() {
        return Color.GREEN;
    }
    
    @Override
    protected int[][] getShape() {
        return new int[][] {{0,0}, {1,0}, {-1,1}, {0,1}};
    }
}