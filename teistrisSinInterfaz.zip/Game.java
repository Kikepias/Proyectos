import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

public class Game {
    private static final int BOARD_WIDTH = 10;
    private static final int BOARD_HEIGHT = 20;
    private boolean[][] board;
    private Piece currentPiece;
    private boolean isGameOver;
    private int score;
    
    public Game() {
        board = new boolean[BOARD_HEIGHT][BOARD_WIDTH];
        reset();
    }
    
    public void reset() {
        board = new boolean[BOARD_HEIGHT][BOARD_WIDTH];
        isGameOver = false;
        score = 0;
        spawnNewPiece();
    }
    
    private void spawnNewPiece() {
        currentPiece = new Piece(BOARD_WIDTH / 2 - 1, 0, Color.BLUE);
    }
    
    public void moveLeft() {
        if (!isGameOver && canMove(currentPiece, -1, 0)) {
            currentPiece.moveLeft();
        }
    }
    
    public void moveRight() {
        if (!isGameOver && canMove(currentPiece, 1, 0)) {
            currentPiece.moveRight();
        }
    }
    
    public void moveDown() {
        if (!isGameOver) {
            if (canMove(currentPiece, 0, 1)) {
                currentPiece.moveDown();
            } else {
                placePiece();
                checkLines();
                spawnNewPiece();
                checkGameOver();
            }
        }
    }
    
    public void rotate() {
        if (!isGameOver) {
            currentPiece.rotate();
        }
    }
    
    private boolean canMove(Piece piece, int deltaX, int deltaY) {
        for (Square square : piece.getSquares()) {
            int newX = square.getX() + deltaX;
            int newY = square.getY() + deltaY;
            
            if (newX < 0 || newX >= BOARD_WIDTH || 
                newY < 0 || newY >= BOARD_HEIGHT || 
                board[newY][newX]) {
                return false;
            }
        }
        return true;
    }
    
    private void placePiece() {
        for (Square square : currentPiece.getSquares()) {
            board[square.getY()][square.getX()] = true;
        }
    }
    
    private void checkLines() {
        for (int row = BOARD_HEIGHT - 1; row >= 0; row--) {
            if (isLineComplete(row)) {
                removeLine(row);
                score += 100;
            }
        }
    }
    
    private boolean isLineComplete(int row) {
        for (int col = 0; col < BOARD_WIDTH; col++) {
            if (!board[row][col]) return false;
        }
        return true;
    }
    
    private void removeLine(int row) {
        for (int y = row; y > 0; y--) {
            for (int x = 0; x < BOARD_WIDTH; x++) {
                board[y][x] = board[y-1][x];
            }
        }
    }
    
    private void checkGameOver() {
        isGameOver = !canMove(currentPiece, 0, 0);
    }
    
    public void draw(Graphics g) {
        // Draw the board
        g.setColor(Color.GRAY);
        final int SQUARE_SIZE = 30; // Define a constant for square size
        for (int row = 0; row < BOARD_HEIGHT; row++) {
            for (int col = 0; col < BOARD_WIDTH; col++) {
                if (board[row][col]) {
                    g.fillRect(col * SQUARE_SIZE, row * SQUARE_SIZE, 
                              SQUARE_SIZE, SQUARE_SIZE);
                }
            }
        }
        
        // Draw the current piece
        if (currentPiece != null) {
            currentPiece.draw(g);
        }
    }
    
    public boolean isGameOver() { return isGameOver; }
    public int getScore() { return score; }
}