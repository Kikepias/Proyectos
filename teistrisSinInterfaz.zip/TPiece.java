import java.awt.Color;

public class TPiece extends AbstractPiece {
    public TPiece(int startX, int startY) {
        super(startX, startY);
    }
    
    @Override
    protected Color getColor() {
        return Color.MAGENTA;
    }
    
    @Override
    protected int[][] getShape() {
        return new int[][] {{0,0}, {-1,0}, {1,0}, {0,1}};
    }
}