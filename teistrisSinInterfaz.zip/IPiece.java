import java.awt.Color;

public class IPiece extends AbstractPiece {
    public IPiece(int startX, int startY) {
        super(startX, startY);
    }
    
    @Override
    protected Color getColor() {
        return Color.CYAN;
    }
    
    @Override
    protected int[][] getShape() {
        return new int[][] {{-1,0}, {0,0}, {1,0}, {2,0}};
    }
}