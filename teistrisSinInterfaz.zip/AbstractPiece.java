import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

public abstract class AbstractPiece {
    protected List<Square> squares;
    protected int centerX;
    protected int centerY;
    protected Color color;
    protected static final int SQUARE_SIZE = 30;
    protected int currentRotation = 0;
    
    public AbstractPiece(int startX, int startY) {
        this.squares = new ArrayList<>();
        this.centerX = startX;
        this.centerY = startY;
        this.color = getColor();
        createSquares();
    }
    
    protected abstract Color getColor();
    protected abstract int[][] getShape();
    
    protected void createSquares() {
        squares.clear();
        int[][] shape = getShape();
        
        for (int[] pos : shape) {
            squares.add(new Square(centerX + pos[0], centerY + pos[1], color, SQUARE_SIZE));
        }
    }
    
    public void moveDown() {
        centerY++;
        squares.forEach(Square::moveDown);
    }
    
    public void moveLeft() {
        centerX--;
        squares.forEach(Square::moveLeft);
    }
    
    public void moveRight() {
        centerX++;
        squares.forEach(Square::moveRight);
    }
    
    public void rotate() {
        if (!canRotate()) return;
        
        currentRotation = (currentRotation + 1) % 4;
        List<Square> oldSquares = new ArrayList<>(squares);
        squares.clear();
        
        for (Square square : oldSquares) {
            int relX = square.getX() - centerX;
            int relY = square.getY() - centerY;
            
            int newRelX = -relY;
            int newRelY = relX;
            
            squares.add(new Square(centerX + newRelX, centerY + newRelY, color, SQUARE_SIZE));
        }
    }
    
    protected boolean canRotate() {
        return true;
    }
    
    public void draw(Graphics g) {
        squares.forEach(square -> {
            g.setColor(square.getColor());
            g.fillRect(square.getX() * SQUARE_SIZE, 
                      square.getY() * SQUARE_SIZE, 
                      square.getSize(), 
                      square.getSize());
            
            g.setColor(Color.WHITE);
            g.drawRect(square.getX() * SQUARE_SIZE,
                      square.getY() * SQUARE_SIZE,
                      square.getSize(),
                      square.getSize());
        });
    }
    
    public List<Square> getSquares() {
        return squares;
    }
    
    public int getCenterX() { return centerX; }
    public int getCenterY() { return centerY; }
}